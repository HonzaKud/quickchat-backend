import { Request, Response } from 'express';
import User from '../models/User';
import { hashPassword } from '../services/authService';

// Příklad registrace uživatele
export const registerUser = async (req: Request, res: Response) => {
  const { username, email, password } = req.body;

  try {
    // Kontrola, jestli už existuje uživatel
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Uživatel s tímto emailem již existuje.' });
    }

    const hashedPassword = await hashPassword(password);

    const newUser = new User({
      username,
      email,
      password: hashedPassword,
    });

    await newUser.save();

    return res.status(201).json({ message: 'Registrace proběhla úspěšně.' });
  } catch (error) {
    console.error('Chyba při registraci:', error);
    return res.status(500).json({ message: 'Chyba serveru.' });
  }
};
