import express from 'express';
import { registerUser } from '../controllers/authController';

// Správně: použij express.Router()
const router = express.Router();

// Registrace cesty - POST /register
router.post('/register', registerUser);

export default router;
